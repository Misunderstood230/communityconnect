from django.contrib import admin
from .models import*

admin.site.register(Reg)
admin.site.register(Mod)
admin.site.register(Request)
admin.site.register(ChatMessage)
admin.site.register(AdminRequest)
admin.site.register(Accept_Request)
admin.site.register(CreativeContent)
admin.site.register(Feedback)
admin.site.register(Session_by_Mentor)
admin.site.register(MentoringSession)
admin.site.register(Like)

